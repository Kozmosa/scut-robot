rm mask*
rm result*