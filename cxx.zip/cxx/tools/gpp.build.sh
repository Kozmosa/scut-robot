g++ armor_cpp.cpp -o armor_cpp `pkg-config opencv4 --cflags --libs` -lspdlog
